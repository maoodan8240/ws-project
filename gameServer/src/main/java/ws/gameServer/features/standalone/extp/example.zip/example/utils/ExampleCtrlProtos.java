package ws.gameServer.features.standalone.extp.example.utils;

public class ExampleCtrlProtos {

}
