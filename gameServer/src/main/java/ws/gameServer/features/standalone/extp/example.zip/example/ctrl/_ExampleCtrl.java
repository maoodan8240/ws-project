package ws.gameServer.features.standalone.extp.example.ctrl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ws.common.utils.di.GlobalInjector;
import ws.gameServer.features.standalone.actor.player.mc.controler.AbstractPlayerExteControler;
import ws.gameServer.features.standalone.extp.itemIo.ItemIoExtp;
import ws.gameServer.features.standalone.extp.itemIo.ctrl.ItemIoCtrl;
import ws.gameServer.system.date.dayChanged.DayChanged;
import ws.relationship.topLevelPojos.example.Example;

public class _ExampleCtrl extends AbstractPlayerExteControler<Example> implements ExampleCtrl {
    private static final Logger LOGGER = LoggerFactory.getLogger(_ExampleCtrl.class);
    private ItemIoExtp itemIoExtp;
    private ItemIoCtrl itemIoCtrl;

    @Override
    public void _initReference() throws Exception {
        itemIoExtp = getPlayerCtrl().getExtension(ItemIoExtp.class);
        itemIoCtrl = itemIoExtp.getControlerForQuery();
    }

    @Override
    public void _resetDataAtDayChanged() throws Exception {
        if (!GlobalInjector.getInstance(DayChanged.class).getDayChangedStr().equals(target.getLastResetDay())) {
            target.setLastResetDay(GlobalInjector.getInstance(DayChanged.class).getDayChangedStr());
            save();
        }
    }

    @Override
    public void sync() {

    }

    @Override
    public void a() {
    }

    @Override
    public void b() {
    }

    @Override
    public void c() {
    }

  
}
