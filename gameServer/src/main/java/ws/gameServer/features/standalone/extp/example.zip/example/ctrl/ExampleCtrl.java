package ws.gameServer.features.standalone.extp.example.ctrl;


import ws.gameServer.features.standalone.actor.player.mc.controler.PlayerExteControler;
import ws.relationship.topLevelPojos.example.Example;

public interface ExampleCtrl extends PlayerExteControler<Example> {

    void a();

    void b();

    void c();

}
